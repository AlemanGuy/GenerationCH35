### ¿Que hace el codigo?

El codigo trata de una lista a la cual se le deben agregar invitados con los campos de:

- nombre
- edad
- nacionalidad
  Una vez llenos los campos se debe apretar el boton submit y deberian verse reflejados en la parte de lista de invitados

### Bugs HTML

- El div que contendra los invitamos no tiene un id.

### Bugs js

- Tiene metodos declarados dentro de metodos
- El metodo crearElemento realiza la misma funcion que el codigo antes de el
- El nombre del parametro que se usa para la funcion submit, tiene el mismo nombre que la que se declara para la edad
