package poo4org.generation.figuras;

abstract class Figura {
	public abstract double calcularArea();
	public void infoFigura() {
		System.out.println("Esta es una figura");
	}	
}
